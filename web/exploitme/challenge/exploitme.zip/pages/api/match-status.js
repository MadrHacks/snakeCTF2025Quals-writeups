import openDb from '@/lib/db.js';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret'; // Use environment variable in production

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization token required' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const currentUserId = decoded.userId;

    const { targetUsername } = req.query;

    if (!targetUsername) {
      return res.status(400).json({ message: 'Target username is required' });
    }

    const db = await openDb();

    const targetUser = await db.get('SELECT id FROM users WHERE username = ?', targetUsername);
    if (!targetUser) {
      return res.status(404).json({ message: 'Target user not found' });
    }
    const targetUserId = targetUser.id;

    const currentUserLiked = await db.get(
      'SELECT 1 FROM likes WHERE liker_id = ? AND liked_id = ?',
      currentUserId,
      targetUserId
    );

    const targetUserLiked = await db.get(
      'SELECT 1 FROM likes WHERE liker_id = ? AND liked_id = ?',
      targetUserId,
      currentUserId
    );

    let matchId = null;
    if (currentUserLiked && targetUserLiked) {
      const match = await db.get(
        'SELECT id FROM matches WHERE (user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)',
        currentUserId, targetUserId, targetUserId, currentUserId
      );
      if (match) {
        matchId = match.id;
      }
    }

    res.status(200).json({
      currentUserLiked: !!currentUserLiked,
      targetUserLiked: !!targetUserLiked,
      isMatch: !!(currentUserLiked && targetUserLiked),
      matchId: matchId,
    });

  } catch (error) {
    console.error('Match status API error:', error);
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Invalid token' });
    }
    res.status(500).json({ message: 'Internal server error' });
  }
}
