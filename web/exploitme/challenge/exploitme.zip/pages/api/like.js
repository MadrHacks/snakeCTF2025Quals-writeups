import openDb from '@/lib/db.js';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret'; // Use environment variable in production

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization token required' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const likerId = decoded.userId;

    const { likedUsername } = req.body;

    if (!likedUsername) {
      return res.status(400).json({ message: 'Liked username is required' });
    }

    const db = await openDb();

    const likedUser = await db.get('SELECT id FROM users WHERE username = ?', likedUsername);
    if (!likedUser) {
      return res.status(404).json({ message: 'User to like not found' });
    }
    const likedId = likedUser.id;

    if (likerId === likedId) {
      return res.status(400).json({ message: 'Cannot like yourself' });
    }

    try {
      await db.run('INSERT INTO likes (liker_id, liked_id) VALUES (?, ?)', likerId, likedId);
    } catch (error) {
      if (error.message.includes('UNIQUE constraint failed')) {
        return res.status(409).json({ message: 'You have already liked this user' });
      }
      throw error;
    }

    const mutualLike = await db.get(
      'SELECT * FROM likes WHERE liker_id = ? AND liked_id = ?',
      likedId,
      likerId
    );

    if (mutualLike) {
      try {
        await db.run('INSERT INTO matches (user1_id, user2_id) VALUES (?, ?)', likerId, likedId);
        return res.status(200).json({ message: 'It\'s a match!', match: true });
      } catch (error) {
        if (error.message.includes('UNIQUE constraint failed')) {
          return res.status(200).json({ message: 'Already matched!', match: true });
        }
        throw error;
      }
    } else {
      return res.status(200).json({ message: 'Like recorded', match: false });
    }

  } catch (error) {
    console.error('Like API error:', error);
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Invalid token' });
    }
    res.status(500).json({ message: 'Internal server error' });
  }
}
