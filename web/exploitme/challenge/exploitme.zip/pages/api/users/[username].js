import openDb from '@/lib/db.js';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret'; // Use environment variable in production

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization token required' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    const { username } = req.query;

    if (!username) {
      return res.status(400).json({ message: 'Username is required' });
    }

    const db = await openDb();

    const user = await db.get(
      `SELECT id, username, email, role, looking_for, age, likes, dislikes, bio, location, hacks, favorite_hacker, favorite_song, favorite_movie, yt_embed, pictures
       FROM users
       WHERE username = ? AND is_onboarded = TRUE`,
      username
    );

    if (!user) {
      return res.status(404).json({ message: 'User not found or not onboarded' });
    }

    const parsedUser = {
      ...user,
      likes: user.likes ? JSON.parse(user.likes) : [],
      dislikes: user.dislikes ? JSON.parse(user.dislikes) : [],
      hacks: user.hacks ? JSON.parse(user.hacks) : [],
      pictures: user.pictures ? JSON.parse(user.pictures) : [],
    };

    res.status(200).json({ user: parsedUser });

  } catch (error) {
    console.error('Error fetching single user:', error);
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Invalid token' });
    }
    res.status(500).json({ message: 'Internal server error' });
  }
}
