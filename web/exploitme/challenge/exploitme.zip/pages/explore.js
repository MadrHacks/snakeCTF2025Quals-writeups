import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/router';

import Link from 'next/link';
import Logo from '@/components/Logo';

const Names = {
  WHITE_HAT: "White Hat",
  BLACK_HAT: "Black Hat",
  GREY_HAT: "Grey Hat",
};

const UserCard = ({ user }) => (
  <Link href={`/users/${user.username}`}>
    <div className="max-w-xs bg-white/50 rounded-lg shadow-lg border border-slate-200 h-full">
      {user.pictures && user.pictures.length > 0 ? (
        <img src={user.pictures[0]} alt={user.username} className="w-full aspect-square object-cover rounded-t-md" />
      ) : (
        <div className="w-full aspect-square bg-gray-200 rounded-t-md flex items-center justify-center">
          <span className="text-gray-500 text-center">
            No picture available
            <br />
            <span className="text-xs italic">(must be an actual hacker, no way)</span>
          </span>
        </div>
      )}

      <div className="py-4 px-6">
        <h2 className="text-2xl font-bold mb-2 line-clamp-2">{user.username} ({user.age})</h2>
        <p className="text-slate-900/60 mb-2">{user.bio}</p>
        <p className="text-slate-900/60 text-sm"><strong>Is a:</strong> {Names[user.role]}</p>
        <p className="text-slate-900/60 text-sm"><strong>Looking For:</strong> {Names[user.looking_for]}</p>
        <p className="text-slate-900/60 text-sm"><strong>Location:</strong> {user.location || "Not set"}</p>
      </div>
    </div>
  </Link>
);

export default function Explore() {
  const router = useRouter();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true);
      const token = localStorage.getItem("jwt");
      if (!token) {
        router.push('/login');
        setLoading(false);
        return;
      }

      try {
        const res = await fetch(`/api/users`, {
          headers: {
            "Authorization": `Bearer ${token}`,
          },
        });

        if (res.ok) {
          const data = await res.json();
          setUsers((prevUsers) => [...prevUsers, ...data.users]);
        } else if (res.status === 403) {
          router.push('/onboarding');
        } else {
          console.error("Failed to fetch users:", await res.json());
          router.push('/login');
        }
      } catch (error) {
        router.push('/login');
      } finally {
        setLoading(false);
      }
    };

    const checkOnboardingAndFetchUsers = async () => {
      const token = localStorage.getItem("jwt");
      if (!token) {
        router.push('/login');
        return;
      }

      try {
        const res = await fetch("/api/onboarding/check", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
          }
        });

        if (res.status === 200) {
          fetchUsers();
        } else if (res.status === 403) {
          router.push('/onboarding');
        } else {
          console.error("Error checking onboarding status:", await res.json());
          router.push('/login');
        }
      } catch (error) {
        console.error('Network error checking onboarding status:', error);
        router.push('/login');
      }
    };

    checkOnboardingAndFetchUsers();
  }, [router]);

  return (<>
    <Logo className="size-24 mx-auto my-4 fill-slate-900/40" />

    <h1 className="text-3xl font-black text-center text-slate-900/80">Welcome to ExploitMe!</h1>
    <p className="text-lg text-bold text-center text-slate-900/60 mt-1">
      The dating app for any kind of hackers.
    </p>
    <div className="grid grid-cols-2 gap-4 p-4 max-w-fit mx-auto mt-4">
      {users.map((user) => (
        <UserCard key={user.id} user={user} />
      ))}
    </div>

    {loading && <p className="text-center text-gray-600 mt-4">Loading more users...</p>}
    {users.length > 0 && <p className="text-center text-gray-600 mt-4 mb-8">You reached the end</p>}
    {users.length === 0 && !loading && <p className="text-center text-gray-600 mt-4">There is nothing to show you :-(</p>}
  </>);
}
