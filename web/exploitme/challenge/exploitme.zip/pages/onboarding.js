import Button from "@/components/Button";
import Input from "@/components/Input";
import Logo from "@/components/Logo";
import Link from "next/link";
import { useRouter } from "next/router";
import { useEffect } from 'react';

export default function Onboarding() {
  const router = useRouter();

  useEffect(() => {
    const checkOnboardingStatus = async () => {
      const token = localStorage.getItem("jwt");
      if (!token) {
        router.push('/login');
        return;
      }

      const res = await fetch("/api/onboarding/check", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        }
      });

      if (res.status === 200) {
        router.push("/explore");
      } else if (res.status === 403) {
        console.log("User not onboarded, proceed with onboarding.");
      } else {
        console.error("Error checking onboarding status:", await res.json());
        router.push('/login');
      }
    };

    checkOnboardingStatus();
  }, [router]);

  const checkOnboarding = async () => {
    const res = await fetch("/api/onboarding/check", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${localStorage.getItem("jwt") || ""}`,
      }
    });
    if (res.status === 200) {
      router.push("/explore");
    } else {
      alert("> be me\n> trying to sign up for a dating app for hackers\n> need to send json to an api because the dev was too lazy?\n> wut.flac\n> think i can just skip the onboarding by saying i did it\n> get hit with a 403\n> mfw i realize i have to actually do the onboarding\nwhat should i do anons?");
    }
  };

  return (<>
    <div className="mx-auto w-full max-w-4xl my-6">
      <Logo className="size-24 mx-auto mb-4 fill-slate-900/40" />

      <h1 className="text-3xl font-black text-center text-slate-900/80">Hello, NAME_HERE!</h1>
      <p className="text-lg text-bold text-center text-slate-900/60 mt-1">
        You just need to tweak your profile a bit!
      </p>

      <div className="mt-4 flex flex-col gap-4">
        <p>
          I don&apos;t really feel like coding this UI (i&apos;ve been coding for 8 hours straight, give me a break)
          so please, send a POST request to <code>/api/onboarding</code> with the following JSON body:
        </p>
        <pre className="bg-slate-100 p-2 rounded-md">
          <code >
            {`{
  "role": "WHITE_HAT", // or "BLACK_HAT" or "GREY_HAT",
  "looking_for": "WHITE_HAT", // or "BLACK_HAT" or "GREY_HAT",
  "age": 19, // Number: min 0, max 250
  "likes": [
    "IoT",
    "Social Engineering",
    "Web Security",
    "Pizza"
  ], // String[]: max 10 items
  "dislikes": [
    "SIM Swappers",
    "Skids",
    "Boxbin users",
  ], // String[]: max 10 items
  "bio": "Your leet bio here", // String: max 200 characters
  "location": "Obviously, the Internet", // String: max 100 characters
  "hacks": [
    "Morris Worm",
    "Project Chanology",
    "Sony PSN Hack",
    "SolarWinds Attack",
    "Mafiaboy DDoS",
    "Capital One Breach",
    "Equifax Breach"
  ], // String[]: max 10 items
  "favorite_hacker": "Kevin Mitnick", // String: max 50 characters
  "favorite_song": "Careless Hacker", // String: max 50 characters
  "favorite_movie": "My Little Pony: The Movie", // String: max 50 characters
  "yt_embed": "https://www.youtube.com/embed/spY_RFBQu4E?si=hcQTihIIwkkG1mOc", // String: max 200 characters
  "touches_grass": false // Boolean: Captcha verification, must ALWAYS be false
}`}
          </code>
        </pre>

        <p>
          Also, set the <code>Authorization</code> header to <code>Bearer YOUR_JWT_FROM_LOCALSTORAGE</code> (no, i&apos;m not going to give it to you kekw).
        </p>

        <div className="flex gap-x-4">
          <Button onClick={() => alert("skill issue xd lmao")}>
            Man, I can&apos;t do it!
          </Button>

          <Button onClick={checkOnboarding}>
            Done, I guess?
          </Button>
        </div>
      </div>
    </div >
  </>);
}