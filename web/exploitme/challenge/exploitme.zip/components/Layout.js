import clsx from "clsx";
import { Inter } from "next/font/google";

const inter = Inter({
    subsets: ["latin"],
    variable: "--font-inter",
});

export default function Layout({ children }) {
    return (<>
        <div
            className={clsx(
                inter.className,
                "flex flex-col min-h-screen"
            )}
        >
            {children}
        </div>
    </>);
}