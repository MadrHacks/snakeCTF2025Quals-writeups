import clsx from "clsx";

export default function Button({
    children,
    className = "",
    ...props
}) {
    return (<>
        <button
            className={clsx(
                "bg-slate-900 text-white px-4 py-2 rounded-md hover:bg-slate-800 transition-colors",
                "focus:outline-none focus:ring-2 focus:ring-slate-900/50 focus:ring-offset-2 w-full",
                className
            )}
            {...props}
        >
            {children}
        </button>
    </>);
}