const { open } = require('sqlite');
const sqlite3 = require('sqlite3');

async function runMigrations() {
  try {
    const db = await open({
      filename: process.env.DB_PATH || './database.db',
      driver: sqlite3.Database
    });

    const flag = process.env.FLAG || 'snakeCTF{f4ke_fl4g_f0r_t3st1ng}';

    await db.exec(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  role TEXT CHECK(role IN ('WHITE_HAT', 'BLACK_HAT', 'GREY_HAT')) DEFAULT 'GREY_HAT',
  looking_for TEXT CHECK(looking_for IN ('WHITE_HAT', 'BLACK_HAT', 'GREY_HAT')) DEFAULT 'WHITE_HAT',  
  age INTEGER CHECK(age >= 0 AND age <= 1337) DEFAULT 0,
  likes TEXT CHECK(length(likes) <= 1000), -- JSON array of strings, max 10 items
  dislikes TEXT CHECK(length(dislikes) <= 1000), -- JSON array of strings, max 10 items
  location TEXT CHECK(length(location) <= 100), -- Location string, max 100 characters
  bio TEXT CHECK(length(bio) <= 500), -- Bio string, max
  hacks TEXT CHECK(length(dislikes) <= 1000), -- JSON array of strings, max 10 items
  is_onboarded BOOLEAN DEFAULT FALSE, -- Boolean to check if the user has completed onboarding
  favorite_hacker TEXT CHECK(length(favorite_hacker) <= 100), -- Favorite hacker string, max 100 characters
  favorite_song TEXT CHECK(length(favorite_song) <= 100), -- Favorite song string, max 100 characters
  favorite_movie TEXT CHECK(length(favorite_movie) <= 100), -- Favorite movie string, max 100 characters
  pictures TEXT CHECK(length(pictures) <= 2000), -- JSON array of strings (URLs), max 2000 characters
  yt_embed TEXT CHECK(length(yt_embed) <= 200), -- YouTube embed URL, max 200 characters
  is_admin BOOLEAN DEFAULT FALSE,
  last_login TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS matches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user1_id INTEGER NOT NULL,
  user2_id INTEGER NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_reported BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (user1_id) REFERENCES users(id),
  FOREIGN KEY (user2_id) REFERENCES users(id),
  UNIQUE(user1_id, user2_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  match_id INTEGER NOT NULL,
  sender_id INTEGER NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (match_id) REFERENCES matches(id),
  FOREIGN KEY (sender_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS likes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  liker_id INTEGER NOT NULL,
  liked_id INTEGER NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (liker_id) REFERENCES users(id),
  FOREIGN KEY (liked_id) REFERENCES users(id),
  UNIQUE(liker_id, liked_id)
);`);

    await db.exec(`INSERT INTO users (username, email, password, role, looking_for, age, likes, dislikes, bio, location, hacks, favorite_hacker, favorite_song, favorite_movie, pictures, yt_embed, is_onboarded)
VALUES
(
  "0xAdmin1337",
  "admin@exploitme.lol",
  "",
  "WHITE_HAT",
  "BLACK_HAT",
  1337,
  '["secure coding", "honeypots", "threat intel"]',
  '["phishing", "0day leaks"]',
  "I built this place to find someone dangerous enough to impress me.",
  "Signal HQ",
  '[]',
  "The Jester",
  "Careless Hacker",
  "Citizenfour",
  '["/admin.png", "/admin1.png"]',
  "https://www.youtube.com/embed/spY_RFBQu4E?si=hcQTihIIwkkG1mOc",
  TRUE
),
(
  "BepiFrico",
  "bepi@exploitme.lol",
  "",
  "BLACK_HAT",
  "WHITE_HAT",
  3,
  '["bit flipping", "python obfuscation", "sneaky links"]',
  '["firewalls", "rate limits"]',
  "if you're not admin, don't even like me.",
  "Under your router",
  '["WannaCry", "Ashley Madison Breach", "Stuxnet"]',
  "L0pht Heavy Industries",
  "You're on Boxbin",
  "The Matrix",
  '["/bepi.webp"]',
  "https://www.youtube.com/embed/c4PqZp8nowQ?si=53OmBh1O3ZcOpKLb",
  TRUE
),
(
  "Mr. Priest",
  "paier@exploitme.lol",
  "",
  "GREY_HAT",
  "WHITE_HAT",
  27,
  '["network", "forensics"]',
  '["social engineers"]',
  "🙀",
  "in your heart",
  '[]',
  "DerpTrolling",
  "Baby Shark",
  "精武門",
  '["/priest.png"]',
  "https://www.youtube.com/embed/XqZsoesa55w?si=rHScLgIjpbn0T77o",
  TRUE
),(
  "Dude",
  "dude@exploitme.lol",
  "",
  "BLACK_HAT",
  "WHITE_HAT",
  23,
  '["exploits", "CTFs", "reverse shells"]',
  '["2FA", "captcha"]',
  "just a dude tryna hack love. or the admin. whichever comes first.",
  "The Net",
  '["cookie tossing", "cache poisoning", "deserialization"]',
  "Captain Crunch",
  "Never Gonna Give You Up by Rick Astley",
  "Hackers (1995)",
  '["/dude.png"]',
  "https://www.youtube.com/embed/dQw4w9WgXcQ?si=uwzu-CvfTcLQk5RN",
  TRUE
);`);

    await db.exec(`INSERT INTO matches (user1_id, user2_id) VALUES (3, 4);
INSERT INTO messages (match_id, sender_id, content) VALUES (1, 3, 'hey');
INSERT INTO messages (match_id, sender_id, content) VALUES (1, 4, 'sup');
INSERT INTO messages (match_id, sender_id, content) VALUES (1, 3, 'wanna hack the government?');
INSERT INTO messages (match_id, sender_id, content) VALUES (1, 4, 'sure');
INSERT INTO messages (match_id, sender_id, content) VALUES (1, 3, 'let me just download this script from github');
INSERT INTO messages (match_id, sender_id, content) VALUES (1, 4, 'oh');
INSERT INTO messages (match_id, sender_id, content) VALUES (1, 4, 'you''re not one of those script kiddies, are you?');
INSERT INTO messages (match_id, sender_id, content) VALUES (1, 3, 'no, i''m a professional hacker');
INSERT INTO messages (match_id, sender_id, content) VALUES (1, 4, 'hmmmmm... you use burp suite?');
INSERT INTO messages (match_id, sender_id, content) VALUES (1, 3, 'no, i use the browser dev tools');
INSERT INTO messages (match_id, sender_id, content) VALUES (1, 4, 'oh, you''re actually a pro then');

INSERT INTO matches (user1_id, user2_id) VALUES (4, 1);
INSERT INTO messages (match_id, sender_id, content) VALUES (3, 4, 'yo, wanna listen to some music?');
INSERT INTO messages (match_id, sender_id, content) VALUES (3, 1, 'sure, what do you have in mind?');
INSERT INTO messages (match_id, sender_id, content) VALUES (3, 4, 'careless hacker or endpoint tonight?');
INSERT INTO messages (match_id, sender_id, content) VALUES (3, 1, 'oh, i love those songs');
INSERT INTO messages (match_id, sender_id, content) VALUES (3, 4, 'i know right?');
INSERT INTO messages (match_id, sender_id, content) VALUES (3, 1, 'i can''t wait to hear them live at the finals');
INSERT INTO messages (match_id, sender_id, content) VALUES (3, 4, 'me too, it''s gonna be epic');
INSERT INTO messages (match_id, sender_id, content) VALUES (3, 1, 'i hope we can meet there');
INSERT INTO messages (match_id, sender_id, content) VALUES (3, 4, 'yeah, that would be great');
INSERT INTO messages (match_id, sender_id, content) VALUES (3, 1, 'also the guy who sings it is really cute (totally not the dude that made this challenge)');

INSERT INTO matches (user1_id, user2_id) VALUES (1, 2);
INSERT INTO messages (match_id, sender_id, content) VALUES (4, 1, 'hey');
INSERT INTO messages (match_id, sender_id, content) VALUES (4, 2, 'sSssSSssSSssssSSssSSssSSssS');
INSERT INTO messages (match_id, sender_id, content) VALUES (4, 1, 'yoooo that''s hot');
INSERT INTO messages (match_id, sender_id, content) VALUES (4, 2, 'sSSSsSSssSSssSSssSSssSSssS');
INSERT INTO messages (match_id, sender_id, content) VALUES (4, 1, 'damn you freaky');
INSERT INTO messages (match_id, sender_id, content) VALUES (4, 2, 'sssSssSSssSSSssSSSSSS');
INSERT INTO messages (match_id, sender_id, content) VALUES (4, 1, 'yeah we can meet up, where?');
INSERT INTO messages (match_id, sender_id, content) VALUES (4, 2, 'sSSSssSSssSSssSSssSSssSSssSSssSSssS');
INSERT INTO messages (match_id, sender_id, content) VALUES (4, 1, 'ok, so at ${flag} then?');
INSERT INTO messages (match_id, sender_id, content) VALUES (4, 2, 'sSSSssSSssSSssSSssSSssSSssSSssSSssS');
INSERT INTO messages (match_id, sender_id, content) VALUES (4, 1, 'can''t wait to see you (let''s use a vpn)');

INSERT INTO matches (user1_id, user2_id) VALUES (3, 1);
INSERT INTO messages (match_id, sender_id, content) VALUES (2, 3, 'hey');
INSERT INTO messages (match_id, sender_id, content) VALUES (2, 1, 'sup');
INSERT INTO messages (match_id, sender_id, content) VALUES (2, 3, 'do you wanna like meet up?');
INSERT INTO messages (match_id, sender_id, content) VALUES (2, 1, 'tf, no?');
INSERT INTO messages (match_id, sender_id, content) VALUES (2, 3, 'why not?');
INSERT INTO messages (match_id, sender_id, content) VALUES (2, 1, 'i don''t know you');
INSERT INTO messages (match_id, sender_id, content) VALUES (2, 3, 'i mean, we can get to know each other');
INSERT INTO messages (match_id, sender_id, content) VALUES (2, 1, 'i''m not sure about that');`);

    console.log('Database migrations ran successfully.');
  } catch (error) {
    console.error('Error running database migrations:', error);
    process.exit(1);
  }
}

runMigrations();
