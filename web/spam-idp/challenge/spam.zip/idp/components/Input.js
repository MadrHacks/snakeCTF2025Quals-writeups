export default function Input({
    type = "text",
    placeholder = "",
    className = "",
    ...props
}) {
    return (
        <input
            type={type}
            placeholder={placeholder}
            className={`w-full bg-white/10 text-white rounded-md py-2 px-4 border border-white/25 ${className}`}
            {...props}
        />
    );
}