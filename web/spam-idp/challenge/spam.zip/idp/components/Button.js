import clsx from "clsx";

export default function Button({
    children,
    className = "",
    ...props
}) {
    return (
        <button
            className={clsx(
                "px-6 py-1 text-sm rounded-md text-white border-blue-500 hover:border-blue-600 border bg-blue-500/50 hover:bg-blue-600 transition-colors",
                className
            )}
            {...props}
        >
            {children}
        </button>
    );
}