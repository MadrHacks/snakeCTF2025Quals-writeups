import { useEffect, useState } from "react";

import Link from "next/link";
import { useRouter } from "next/router";
import { Geist } from "next/font/google";

import clsx from "clsx";
import Button from "./Button";

const geistSans = Geist({
    variable: "--font-geist-sans",
    subsets: ["latin"],
});

export default function Layout({ children }) {
    const router = useRouter();
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
        if (typeof document !== "undefined") {
            setIsLoggedIn(document.cookie.split(';').some((item) => item.trim().startsWith('token=')));
        }
    }, [router.pathname]);

    return (<>
        <div
            className={clsx(
                geistSans.variable,
                "min-h-screen flex flex-col font-[var(--font-geist-sans)]",
            )}
        >
            <header
                className="bg-white/5 text-gray-100"
            >
                <nav className="container mx-auto flex justify-between items-center p-4">
                    <Link
                        href="/"
                        className="text-lg font-bold"
                    >
                        SPAM <span className="text-blue-400">IDP</span>
                    </Link>

                    <ul className="flex space-x-4">
                        {
                            isLoggedIn ? (<>
                                <Link href="/dashboard">
                                    <Button>
                                        Dashboard
                                    </Button>
                                </Link>
                                <Link href="/logout">
                                    <Button>
                                        Logout
                                    </Button>
                                </Link>
                            </>) : (<>
                                <Link href="/signup">
                                    <Button>
                                        Signup
                                    </Button>
                                </Link>
                                <Link href="/signin">
                                    <Button>
                                        Signin
                                    </Button>
                                </Link>
                            </>)
                        }
                    </ul>
                </nav>
            </header>

            <main className="flex-1 container mx-auto p-4">
                {children}
            </main>
        </div>
    </>);
};