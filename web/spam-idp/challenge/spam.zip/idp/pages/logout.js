export default function Logout() {
    return (
        <p>
            Logging out...
        </p>
    );
}

export async function getServerSideProps({ req, res }) {
    res.setHeader('Set-Cookie', [
        `token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; SameSite=Lax`
    ]);

    return {
        redirect: {
            destination: '/',
            permanent: false,
        },
    };
}