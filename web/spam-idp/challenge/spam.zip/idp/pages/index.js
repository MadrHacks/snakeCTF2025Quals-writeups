import Link from "next/link";

import Button from "@/components/Button";
import { openDb, getServices } from "@/lib/database";

export default function Home({
  isLoggedIn = false,
  services = [],
}) {
  return (<>
    <h1 className="text-3xl font-bold text-center mt-10">
      Welcome to SPAM IDP!
    </h1>
    <h2 className="text-xl text-center mt-4">
      Sistema Pubblico di Autenticazione Malfunzionante Italiano
      <br />
      <span className="text-white/50 italic text-base">Italian Public System of Malfunctioning Authentication</span>
    </h2>

    {
      isLoggedIn ? (<>
        <Link href="/dashboard">
          <Button className="mt-10 mx-auto block max-w-xs w-full">
            Dashboard
          </Button>
        </Link>
      </>) : (<>
        <Link href="/signup">
          <Button className="mt-10 mx-auto block max-w-xs w-full">
            Signup
          </Button>
        </Link>

        <Link href="/signin">
          <Button className="mt-4 mx-auto block max-w-xs w-full">
            Signin
          </Button>
          </Link>
      </>)
    }

    {
      services.length > 0 && (
        <div className="mt-10 max-w-2xl mx-auto">
          <h2 className="text-xl font-semibold mb-4">Available Services</h2>
          <ul className="space-y-4">
            {services.map((service) => (
              <li key={service.id} className="bg-white/5 p-4 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold">{service.name}</h3>
                <p>{service.description}</p>
                <Link href={service.homepage} target="_blank" rel="noopener noreferrer">
                  <Button className="mt-2">Access Service</Button>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )
    }
  </>);
};

export async function getServerSideProps(context) {
  const token = context.req.cookies.token;

  const db = await openDb();
  const services = await getServices(db);

  return {
    props: {
      isLoggedIn: !!token,
      services: services || [],
    },
  };
}