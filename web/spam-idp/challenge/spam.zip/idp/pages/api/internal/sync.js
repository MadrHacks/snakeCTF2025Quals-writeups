import { openDb } from "@/lib/database";
import { authRequired } from "@/lib/auth";

import CORS from "cors";

const cors = CORS({
    origin: "*",
    methods: ["GET", "POST", "PATCH", "DELETE"],
});

function runMiddleware(req, res, fn) {
    return new Promise((resolve, reject) => {
        fn(req, res, (result) => {
            if (result instanceof Error) return reject(result)
            return resolve(result)
        })
    })
}

export default async function handler(req, res) {
    await runMiddleware(req, res, cors);

    if (req.method !== "POST") {
        res.setHeader("Allow", ["POST"]);
        return res.status(405).end(`Method ${req.method} Not Allowed`);
    }

    const userData = await authRequired(req, res, true, req.query.id);
    if (!userData) return;

    if (userData.groupName !== "System") {
        return res.status(403).json({ error: "You do not have permission to perform this action" });
    }

    const {
        firstName,
        lastName,
        email,
    } = req.body;

    const db = await openDb();
    let query = "UPDATE users";
    if (firstName || lastName || email) {
        query += " SET";
        const updates = [];
        if (firstName) updates.push(` firstName = ?`);
        if (lastName) updates.push(` lastName = ?`);
        if (email) updates.push(` email = ?`);
        query += updates.join(",");
        query += " WHERE id = ?";
    }

    const params = [];
    if (firstName) params.push(firstName);
    if (lastName) params.push(lastName);
    if (email) params.push(email);
    params.push(userData.userId);

    try {
        const result = await db.run(query, params);
        if (result.changes > 0) {
            return res.status(200).json({ message: "User data updated successfully" });
        } else {
            return res.status(400).json({ error: "No changes made or user not found" });
        }
    } catch (error) {
        console.error("Database error:", error);
        return res.status(500).json({ error: "Internal server error" });
    }
}