import { useRouter } from "next/router";

import Input from "@/components/Input";
import Button from "@/components/Button";

export default function Forgot() {
    const router = useRouter();

    const handleSendToken = async (e) => {
        e.preventDefault();

        const formData = {
            email: e.target.email.value,
        };

        const response = await fetch('/api/auth/forgot', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error("Forgot password failed:", errorData);
            alert("Forgot password failed: " + errorData.error);
            return;
        }

        const result = await response.json();
        alert(result.message);
    };

    const handleResetPassword = async (e) => {
        e.preventDefault();

        const formData = {
            newPassword: e.target.password.value,
            token: router.query.token,
        };

        const response = await fetch('/api/auth/forgot', {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        });
        const result = await response.json();
        if (!response.ok) {
            console.error("Reset password failed:", result);
            alert("Reset password failed: " + result.error);
            return;
        }

        alert("Password reset successfully. You can now sign in with your new password.");
        router.push('/signin');
    };

    if (router.query.token) {
        return (<>
            <h1 className="text-3xl font-bold text-center mt-10">
                Forgot password
            </h1>

            <form onSubmit={handleResetPassword} className="flex flex-col items-center mt-4">
                <Input
                    id="password"
                    type="password"
                    placeholder="New password"
                    className="mb-4 w-full max-w-xs"
                />

                <Button className="w-full max-w-xs">
                    Reset password
                </Button>
            </form>
        </>)
    }

    return (<>
        <h1 className="text-3xl font-bold text-center mt-10">
            Forgot password
        </h1>

        <form onSubmit={handleSendToken} className="flex flex-col items-center mt-4">
            <Input
                id="email"
                type="email"
                placeholder="Email"
                className="mb-4 w-full max-w-xs"
            />

            <Button className="w-full max-w-xs">
                Send reset link
            </Button>
        </form>
    </>);
};