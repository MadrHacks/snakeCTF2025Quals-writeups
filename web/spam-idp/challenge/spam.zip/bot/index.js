require("dotenv").config();

// Polyfill for File global if not available (fixes undici compatibility issues)
if (typeof global.File === 'undefined') {
    global.File = class File {
        constructor(fileBits, fileName, options) {
            this.name = fileName;
            this.size = 0;
            this.type = options?.type || '';
            this.lastModified = Date.now();
        }
    };
}

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

const express = require("express");
const jwt = require("jsonwebtoken");
const puppeteer = require("puppeteer");
const { Agent } = require("undici");

const { PORT, SHOW_LOGS: dbg } = process.env;
const SITE_BASEURL = process.env.LOCAL_IDP_BASE_URL || "http://next-app:3000";
let JWT_SECRET = null;
const COLORS = {
    "red": "\x1b[31m",
    "green": "\x1b[32m",
    "reset": "\x1b[0m",
    "blue": "\x1b[34m",
    "reverse": "\x1b[7m"
};
const browser_options = {
    "headless": true,
    "defaultViewport": null,
    "ignoreHTTPSErrors": true,
    "args": [
        "--no-sandbox",
        '--disable-setuid-sandbox',
        "--disable-background-networking",
        "--disable-default-apps",
        "--disable-extensions",
        "--disable-gpu",
        "--disable-sync",
        "--disable-translate",
        "--mute-audio",
        "--hide-scrollbars",
        "--metrics-recording-only",
        "--no-first-run",
        "--safebrowsing-disable-auto-update",
        "--js-flags=--noexpose_wasm,--jitless",
        "--ignore-certificate-errors",
        "--disable-features=AutoupgradeMixedContent"
    ],
};

let oldConsole = { ...console };
console.log = (...args) => oldConsole.log(`${COLORS.reverse}${new Date().toLocaleString()}${COLORS.reset} |`, ...args);
console.error = (...args) => oldConsole.error(`${COLORS.reverse}${new Date().toLocaleString()}${COLORS.reset} |`, ...args);

const sleep = ms => new Promise(res => setTimeout(res, ms));

let currentBots = [];
let finishedBots = [];
let erroredBots = [];
let timedoutBots = [];

let browser = null;

const navigate = async (serviceId, botId) => {
    const services = [
        process.env.LOCAL_TEST_BASE_URL || "http://test:3001",
        process.env.LOCAL_INBS_BASE_URL || "http://inbs:3002",
        process.env.LOCAL_AGENZIA_USCITE_BASE_URL || "http://agenzia-uscite:3003",
        process.env.LOCAL_ASP_BASE_URL || "http://asp:3004",
        process.env.LOCAL_DSW_BASE_URL || "http://dsw:3005"
    ];

    if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Starting navigation to service ${serviceId}: ${services[serviceId]}`);

    currentBots.push({
        id: botId,
        browser,
        start: new Date()
    });

    let page;

    try {
        page = await browser.newPage();

        await page.setExtraHTTPHeaders({
            "ngrok-skip-browser-warning": "true"
        });

        const token = jwt.sign({ userId: 0 }, JWT_SECRET);
        if (dbg) console.error(`${COLORS.blue}[${botId}]${COLORS.reset} - Generated token: ${token}`);

        await page.goto(SITE_BASEURL);
        await page.setCookie({
            "name": "token",
            "value": token,
            "domain": new URL(SITE_BASEURL).hostname,
        });
        await page.setCookie({
            "name": "flag",
            "value": process.env.FLAG || "snakeCTF{f4ke_fl4g_f0r_t3st1ng}",
            "domain": new URL(services[serviceId]).hostname,
        });
        if (dbg) console.error(`${COLORS.blue}[${botId}]${COLORS.reset} - Set cookie`);

        await page.goto(`${SITE_BASEURL}/authorize?serviceId=${serviceId}`);
        await page.waitForSelector("#authorize-btn");

        const authorizationToken = await page.evaluate(() => {
            const props = window.__NEXT_DATA__.props.pageProps;
            return props.token
        });

        if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Authorization token: ${authorizationToken}`);

        if (!authorizationToken) {
            if (dbg) console.error(`${COLORS.red}[${botId}]${COLORS.reset} - No authorization token found. Aborting...`);
            erroredBots.push(botId);
            return;
        }

        const callbackUrl = `${services[serviceId]}/callback?token=${authorizationToken}`;
        if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Making fetch request to: ${callbackUrl}`);
        
        await sleep(1000);

        let response;
        try {
            response = await fetch(callbackUrl, {
                redirect: "manual",
            });
            if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Fetch response status: ${response.status}`);
        } catch (fetchError) {
            if (dbg) console.error(`${COLORS.red}[${botId}]${COLORS.reset} - Fetch error: ${fetchError.message}`);
            if (dbg) console.error(`${COLORS.red}[${botId}]${COLORS.reset} - Fetch error stack: ${fetchError.stack}`);
            
            // Try with undici Agent as fallback
            if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Retrying with undici Agent...`);
            try {
                response = await fetch(callbackUrl, {
                    redirect: "manual",
                    dispatcher: new Agent({
                        connect: {
                            rejectUnauthorized: false,
                            timeout: 30000,
                        },
                    }),
                    signal: AbortSignal.timeout(30000),
                });
                if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Undici fetch response status: ${response.status}`);
            } catch (undiciError) {
                if (dbg) console.error(`${COLORS.red}[${botId}]${COLORS.reset} - Undici fetch also failed: ${undiciError.message}`);
                erroredBots.push(botId);
                return;
            }
        }

        const redirectUrl = response.headers.get("Location");
        const cookies = response.headers.get("Set-Cookie");

        if (!redirectUrl) {
            if (dbg) console.error(`${COLORS.red}[${botId}]${COLORS.reset} - No redirect URL found. Aborting...`);
            erroredBots.push(botId);
            return;
        }
        
        if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Redirect URL: ${redirectUrl}`);
        if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Cookies: ${cookies}`);
        
        if (!cookies) {
            if (dbg) console.error(`${COLORS.red}[${botId}]${COLORS.reset} - No cookies found in response. Aborting...`);
            erroredBots.push(botId);
            return;
        }
        
        const sessionCookie = cookies.split(";").find(cookie => cookie.startsWith("sessionId="));

        if (!sessionCookie) {
            if (dbg) console.error(`${COLORS.red}[${botId}]${COLORS.reset} - No session cookie found. Aborting...`);
            erroredBots.push(botId);
            return;
        }

        const sessionId = sessionCookie.split("=")[1];
        if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Session ID: ${sessionId}`);
        if (!sessionId) {
            if (dbg) console.error(`${COLORS.red}[${botId}]${COLORS.reset} - No session ID found. Aborting...`);
            erroredBots.push(botId);
            return;
        }

        await page.setCookie({
            "name": "sessionId",
            "value": sessionId,
            "domain": new URL(services[serviceId]).hostname,
        });

        if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Cookies set successfully.`);

        let targetUrl;
        if (redirectUrl.startsWith('http')) {
            targetUrl = redirectUrl;
        } else {
            const cleanRedirectUrl = redirectUrl.startsWith('/') ? redirectUrl.substring(1) : redirectUrl;
            targetUrl = `${services[serviceId]}/${cleanRedirectUrl}`;
        }

        if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Final target URL: ${targetUrl}`);

        await page.goto(targetUrl, {
            waitUntil: "networkidle2"
        });

        if (dbg) console.log(`${COLORS.blue}[${botId}]${COLORS.reset} - Navigated to redirect URL: ${redirectUrl}`);
        await sleep(10_000);

        if (dbg) console.error(`${COLORS.blue}[${botId}]${COLORS.reset} - Done.`);
        finishedBots.push(botId);
    } catch (e) {
        if (timedoutBots.includes(botId)) return;

        if (dbg) console.error(`${COLORS.red}[${botId}]${COLORS.reset} - Exception:\n${e}`);
        erroredBots.push(botId);

        if (page) await page.close();
    } finally {
        if (timedoutBots.includes(botId)) return;

        await page.close();
        currentBots = currentBots.filter(b => b.id != botId);
    }
};

// Checking if bots are taking too long to run
setInterval(async () => {
    for (const bot of currentBots) {
        if (((new Date() - bot.start) / 1000) > 15_000) {
            try {
                if (dbg) console.log(`${COLORS.blue}[${bot.id}]${COLORS.reset} - Bot timed out. Forcing close...`);
                await bot.browser.close();
                timedoutBots.push(bot.id);
            } catch (e) {
                if (dbg) console.error(`${COLORS.red}[${bot.id}]${COLORS.reset} - Exception:\n${e.stack}`);
                erroredBots.push(bot.id);
            } finally {
                currentBots = currentBots.filter(b => b.id != bot.id);
            }
        }
    }
}, 15_000);

const app = express();
app.use(require("body-parser").json());

app.use((err, req, res, next) => {
    console.error(`${COLORS.red}[SERVER]${COLORS.reset} - Unhandled rejection: ${err.stack}`);

    return res.status(500).json({
        success: false,
        message: "Internal server error"
    });
});
process.on("unhandledRejection", function (reason, p) {
    console.error(`${COLORS.red}[SERVER]${COLORS.reset} - Unhandled rejection: ${reason}`, p);
});

app.get("/status/:id", async (req, res) => {
    const { id: botId } = req.params;
    const bot = currentBots.find((b) => b.id == botId);

    if (!bot) {
        let status;
        if (finishedBots.includes(botId))
            status = "DONE";
        else if (erroredBots.includes(botId))
            status = "CRASHED";
        else if (timedoutBots.includes(botId))
            status = "TIMEDOUT";

        if (status) {
            return res.status(200).json({
                success: true,
                status
            });
        }

        return res.status(404).json({
            success: false,
            message: "Bot not found"
        });
    }

    const procInfo = await bot.browser.process();
    if (!!procInfo.signalCode) {
        if (dbg) console.error(`${COLORS.red}[${botId}]${COLORS.reset} - Bot process died... Moving to erroredBots`);

        erroredBots.push(botId);
        currentBots = currentBots.filter(b => b.id != botId);

        return res.status(200).json({
            success: true,
            status: "CRASHED"
        });
    }

    return res.status(200).json({
        success: true,
        status: "RUNNING"
    })
});

app.post("/visit", async (req, res) => {
    const {
        platform,
        secret
    } = req.body;

    if (typeof platform !== "number" || typeof secret !== "string") {
        return res.status(422).json({
            success: false,
            status: "give me the data"
        });
    }

    JWT_SECRET = secret;

    const botId = (Math.random() + 1).toString(36).substring(2);

    navigate(platform, botId);

    if (dbg) console.log(`${COLORS.blue}[SERVER]${COLORS.reset} - Spawned bot with ID ${COLORS.green}${botId}${COLORS.reset}.`);

    return res.status(200).json({
        success: true,
        visiting: true,
        id: botId
    })
});

app.get("/ping", async (req, res) => {
    res.status = 200;
    res.send("Pong");
    res.end();
});

puppeteer.launch(browser_options).then(b => {
    browser = b;

    app.listen(PORT, (e) => {
        if (e)
            return console.error(`${COLORS.red}[SERVER]${COLORS.reset} - Couldn't start server: ${e}`);

        console.log(`${COLORS.blue}[SERVER]${COLORS.reset} - Started server. Listening on http://0.0.0.0:${PORT}`);
    });
});