require('dotenv').config();
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
const express = require('express');
const crypto = require('crypto');
const app = express();

const port = process.env.PORT;
const serviceId = process.env.SERVICE_ID;

app.use(express.json());
app.use(require('cookie-parser')());

const sessions = new Map();

const fetchUserData = async (token) => {
    const res = await fetch(`${process.env.LOCAL_IDP_BASE_URL || "http://next-app:3000"}/api/internal/user?id=${serviceId}`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        }
    });
    if (!res.ok) {
        throw new Error('Failed to fetch user data');
    }

    return res.json();
};

app.get('/', (req, res) => {
    res.redirect(`${process.env.IDP_BASE_URL || "http://localhost:3000"}/authorize?serviceId=${serviceId}`);
});

app.get('/callback', async (req, res) => {
    const token = req.query.token;
    if (!token) {
        return res.status(400).send('Token is required');
    }

    const userData = await fetchUserData(token);
    const sessionId = crypto.randomBytes(16).toString('hex');
    sessions.set(sessionId, {
        ...userData,
        token,
    });
    res.cookie('sessionId', sessionId, { httpOnly: true, secure: true });
    res.redirect('/data');
});

app.get('/logout', (req, res) => {
    const sessionId = req.cookies.sessionId;
    if (sessionId) {
        sessions.delete(sessionId);
        res.clearCookie('sessionId');
    }
    res.redirect('/');
});

app.get('/data', async (req, res) => {
    const sessionId = req.cookies.sessionId;
    if (!sessionId || !sessions.has(sessionId)) {
        return res.status(401).send('Unauthorized');
    }

    const userData = sessions.get(sessionId);
    if (!userData) {
        return res.status(404).send('User not found');
    }
    if (new Date(userData.expiry * 1000) < new Date()) {
        sessions.delete(sessionId);
        return res.redirect('/');
    }

    const data = await fetchUserData(userData.token);
    res.send(JSON.stringify(data, null, 2));
});

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});