export default function Support() {
  return (<>
    <p className="mt-12 mb-6 text-2xl">
      no
    </p>
  </>);
}
